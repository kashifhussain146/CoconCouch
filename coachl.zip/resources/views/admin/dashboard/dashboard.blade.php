@extends('admin.layouts.app')

@section('title')
<title>CoconCoach-Dashboard</title>
@stop

@section('inlinecss')

@stop

@section('breadcrum')

<h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
   Bidding Dashboard
</h1>
<ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
   <li class="breadcrumb-item text-muted">
      <a href="../index.html" class="text-muted text-hover-primary">
          Home </a>
   </li>
   <!--end::Item-->
   <!--begin::Item-->
   <li class="breadcrumb-item">
      <span class="bullet bg-gray-400 w-5px h-2px"></span>
   </li>
   <!--end::Item-->
   
   <!--begin::Item-->
   <li class="breadcrumb-item text-muted">
      Banner </li>
   <!--end::Item-->
</ul>

@stop
@section('content')


<div class="d-flex flex-column mb-5 fv-row bnr-heading">


</div>
<!-- short Despcription -->
<div class="flex-lg-row-fluid ms-lg-7 ms-xl-10 ms-xl-101 ">



</div>
<!-- short Despcription end -->
<div class="d-flex">

</div>

<!-- media-file -->
<div class="card card-flush">
  
</div>
<!-- media-file -->

@stop
@section('inlinejs')

@stop