<div id="kt_app_toolbar" class="app-toolbar  py-3 py-lg-6 ">
    <!--begin::Toolbar container-->
    <div id="kt_app_toolbar_container" class="app-container  container-xxl d-flex flex-stack ">
        <!--begin::Page title-->
        <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3 ">
            <!--begin::Title-->
            @yield('breadcrum')
        </div>
    </div>
</div>