<!-- FAQ Section -->
<section class="">
    <div class="container">
        <div class="row">
            <div class="sec-title text-center">
                <span class="sub-title">TAGLINE HEADING</span>
                <h2>Frequently Asked Questions</h2>
            </div>

            <div class="col">
                <ul class="accordion-box wow fadeInRight">
                    <!--Block-->
                    <li class="accordion block active-block">
                        <div class="acc-btn active">Lorem Ipsum is simply dummy text ?
                            <div class="icon fa fa-plus"></div>
                        </div>
                        <div class="acc-content current">
                            <div class="content">
                                <div class="text">Lorem Ipsum is simply dummy text of the printing and
                                    typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                    </li>
                    <!--Block-->
                    <li class="accordion block">
                        <div class="acc-btn">Lorem Ipsum is simply dummy text ?
                            <div class="icon fa fa-plus"></div>
                        </div>
                        <div class="acc-content">
                            <div class="content">
                                <div class="text">Lorem Ipsum is simply dummy text of the printing and
                                    typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                    </li>
                    <!--Block-->
                    <li class="accordion block">
                        <div class="acc-btn">Lorem Ipsum is simply dummy text ?
                            <div class="icon fa fa-plus"></div>
                        </div>
                        <div class="acc-content">
                            <div class="content">
                                <div class="text">Lorem Ipsum is simply dummy text of the printing and
                                    typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                    </li>
                    <!--Block-->
                    <li class="accordion block">
                        <div class="acc-btn">Lorem Ipsum is simply dummy text ?
                            <div class="icon fa fa-plus"></div>
                        </div>
                        <div class="acc-content">
                            <div class="content">
                                <div class="text">Lorem Ipsum is simply dummy text of the printing and
                                    typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!--End FAQ Section -->