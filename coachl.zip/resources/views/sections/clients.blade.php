<!-- Clients Section   -->
<section class="clients-section">
    <div class="auto-container">
        <!-- Sponsors Outer -->
        <div class="sponsors-outer">
            <!--clients carousel-->
            <ul class="clients-carousel owl-carousel owl-theme">
                <li class="slide-item"> <a href="#"><img src="assets/images/client-1.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="assets/images/client-2.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="assets/images/client-3.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="assets/images/client-4.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="assets/images/client-5.png" alt=""></a> </li>
            </ul>
        </div>
    </div>
</section>
<!--End Clients Section -->